package com.klu.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class DAO {
	@Autowired
	UserInterface repo;
	
	
	public void insert(User user) {
		repo.save(user);
	}
	public List<User>retriveAll(){
		return repo.findAll();	
		}

	public User findUser(String email) {
		return repo.findByEmail(email);
	}
}
