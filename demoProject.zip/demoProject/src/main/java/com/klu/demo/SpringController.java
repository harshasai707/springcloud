package com.klu.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class SpringController {
	@Autowired
	DAO dao;
	@GetMapping("/welcome")
	public String fun1(@RequestParam("name") String name) {
		return "Welcome " + name;
	}
	@PostMapping("/user")
			public String fun2(@RequestBody User user) {
		    dao.insert(user);
				return "server response"+user;
			}
	@GetMapping("/all")
	public List<User> fun3() {
		return dao.retriveAll();
		
	}
	@GetMapping("/email")
	public User fun4(@RequestParam("email")String email) {
		return dao.findUser(email);
	}
	
} 
